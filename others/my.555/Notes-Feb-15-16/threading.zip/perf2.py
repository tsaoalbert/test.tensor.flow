import multiprocessing as mp
import time

ntimes = 100000000

def count(n):
	while n > 0:
		n -= 1

# sequential execution
if __name__ == '__main__': 
    mp.freeze_support() 
    mp.set_start_method('spawn') 
    
    t1_start = time.time()
    count(ntimes)
    count(ntimes)
    t1_end = time.time()
    print("Sequential Execution time = ", 
            t1_end - t1_start)

    t1_start = time.time()
    thread1 = mp.Process(target=count, args=(ntimes,))
    thread2 = mp.Process(target=count, args=(ntimes,))
    thread1.start()
    thread2.start()
    thread1.join()
    thread2.join()
    t1_end = time.time()
    print("Process Execution time = ", 
        t1_end - t1_start)
