from memmgr import MemMgr
import traceback

def change_contents(array1, value1):
    for r in range(0, array1.shape[0]):
        for c in range(0, array1.shape[1]):
            array1[r,c] = value1

"""
try:
    a1 = MemMgr.get_mem(222,13) 
    change_contents(a1, 22)

    a2 = MemMgr.get_mem(333,1) 
    change_contents(a2, 33)

    a3 = MemMgr.get_mem(444,1)
    change_contents(a3, 44)
 
    MemMgr.release_mem(333)

    a4 = MemMgr.get_mem(555, 2)
    change_contents(a4, 55)
except Merror:
    print("memory error caught *******************")
    traceback.print_exc()
    print("**********************")
"""   

print("test")

MemMgr.get_mem(22, 1)
MemMgr.display_mgmt()

MemMgr.get_mem(33,2)
MemMgr.display_mgmt()


MemMgr.get_mem(44,2)
MemMgr.display_mgmt()

MemMgr.release_mem(33)
MemMgr.display_mgmt()

MemMgr.get_mem(55,3)
MemMgr.display_mgmt()


MemMgr.display_mem()
MemMgr.display_mgmt()