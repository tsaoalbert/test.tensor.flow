from thread1 import CountdownThread

t1 = CountdownThread(10) # create the thread object
t1.start() # launch the thread

t2 = CountdownThread(20) # create another thread
t2.start() # launch

t1.join()
t2.join()

print("Exit main thread")